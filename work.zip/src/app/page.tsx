import Nav from "./Components/NavBar/Nav";
import OurProducts from "./Components/OurProducts/OurProducts";
import Products from "./Components/Products/Products";
import FarmFresh from "./Components/FarmFresh/FarmFresh";
import Footer from "./Components/Footer/Footer";
import Dairy from "./Components/Dairy/Dairy";
import MilkBanner from "./Components/MilkBanner/MilkBanner";
import Carousel from "./Components/Carousel/Carousel";
import Farming from "./Components/Farming/Farming";

export default function Home() {
  return (
    <div>
      <Nav />
      <Products />
      <Carousel />
      <OurProducts />
      <Farming />
      <MilkBanner />
      <Dairy />
      <FarmFresh />
      <Footer />
    </div>
  );
}
