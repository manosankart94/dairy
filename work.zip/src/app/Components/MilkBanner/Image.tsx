export default function Image() {
    return (
      <div className="bottleimage relative pl-14"><img src="/29.png" alt="MilkBottle"></img></div>
    );
  }



  




  