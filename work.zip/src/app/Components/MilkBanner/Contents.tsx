export default function Contents() {
    return (
      <div className="milkcontents text-justify relative">
        <div className="headerr text-white font-bold pt-20 pl-6"><h1>A2 Milk</h1></div>
        <div className="contenttext text-white pt-12 pl-8 text-lg font-medium">Farm fresh & pure A2 Gir Cow Milkfrom our own farm.Hi tech dairy farms where we ensure cow comfort,hygiene,health and high quality feed grown by us using own cow manure.</div>
        <button className="subscribebuttonn text-center ml-8 mt-16 absolute rounded-lg py-5">Subscribe</button>
      </div>
    );
  }


  



  


