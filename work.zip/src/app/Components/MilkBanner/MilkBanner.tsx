import Contents from "./Contents";
import Image from "./Image";
import "./Milk.css";

export default function MilkBanner() {
  return (
    <div className="milkcontent flex  justify-around 	m-auto   relative">
      <div className="milkslide absolute"></div>
      <Contents />
      <Image />
    </div>
  );
}









