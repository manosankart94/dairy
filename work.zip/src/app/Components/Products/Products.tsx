"use client";
import Link from "next/link";
import "./Products.css";
import React, { useState } from "react";

export default function Products() {
  const [style, setStyle] = useState({ display: "none" });

  return (
    <>
      <div className=" flex">
        <div className="curve relative"></div>
        <div className="curve1 relative"></div>
      </div>
      <div className="prolist flex items-center justify-between mt-4">
        <div className="listsproducts  w-4/5 justify-center items-center pb-2.5">
          <ul className="mediaproduct name flex m-auto justify-center items-center  gap-x-24  pl-40  py-8">
            <Link href="/MilkLinkPage">
              <li
                onMouseEnter={(e) => {
                  setStyle({ display: "block" });
                }}
                onMouseLeave={(e) => {
                  setStyle({ display: "none" });
                }}
                className="arrowhoverr flex  items-center relative cursor-pointer"
              >
                Milk
                <span className="productdrop pl-1 hover:rotate-180">
                  <img src="/11.png" alt="Dropdown" />
                </span>
                <div className="mainncontainer justify-center items-center absolute flex gap-x-20 py-9">
                  {/* <div className="mainncontainer justify-center items-center  flex gap-x-20 py-9"> */}
                  {/* <img src="/66.png" className="milky pt-3"></img>
                  <img src="/67.png" className="milkk pt-3 pt-7"></img> */}
                </div>
              </li>
            </Link>
            <li className="arrowhover flex items-center relative cursor-pointer">
              Dairy Products
              <span className="productdrop pl-1 hover:rotate-180">
                <img src="/11.png" alt="Dropdown"  />
              </span>
              {/* <div className="maincontainer justify-center absolute flex gap-x-20 py-9">
                <img src="/41.png" className="butterr pt-3"></img>
                <img src="/42.png" className="paneerr pt-3"></img>
                <img src="/43.png" className="gheee pt-3"></img>
              </div> */}
            </li>
            <li className="arrowhover flex relative items-center cursor-pointer">
              Coming Soon
              <span className="productdrop pl-1 hover:rotate-180">
                <img src="/11.png" alt="Dropdown" />
              </span>
              {/* <div className="maincontainerr absolute justify-center items-center absolute flex gap-x-20 py-9">
                <img src="/41.png" className="butterr pt-3"></img>
                <img src="/42.png" className="paneerr pt-3"></img>
                <img src="/43.png" className="gheee pt-3"></img>
              </div> */}
            </li>
            <li className="arrowhover flex  items-center cursor-pointer">
              Blog
              <span className="productdrop pl-1 hover:rotate-180">
                <img src="/11.png" alt="Dropdown"/>
              </span>
            </li>
          </ul>
        </div>
        <div className="kartlist w-1/5">
          <Link href="CartPage">
            <div><img src="/23.png" alt="Cart" className="cartlogo"></img></div>
          </Link>
        </div>
      </div>
      {/* <div style={style} className="mbanner w-full bg-red-700	h-30 relative" 
>
        <ul className="flex justify-center items-center">
          <li className="flex justify-center"><img src="/66.png" className="milky pt-3"></img></li>
          <li className="flex justify-center pl-20 pt-7"><img src="/67.png" className="milky pt-3"></img></li>
        </ul>
      </div> */}
    </>
  );
}








