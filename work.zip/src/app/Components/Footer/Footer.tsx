import "./Footer.css";

export default function Footer() {
  return (
    <div className="footer bg-cover box-border pb-4">
      <div className="w-4/5 m-auto flex justify-around">
        <div className="w-1/4">
          <ul className="footertext m-0 p-0 list-none text-justify flex flex-col	gap-y-1.5  pl-10 ">
            <li className="text-lg text-white pt-28">
              <h1>COMPANY</h1>
            </li>
            <li className="text-xs text-white cursor-pointer">Who We are</li>
            <li className="text-xs text-white cursor-pointer">
              Privacy Policy
            </li>
            <li className="text-xs text-white cursor-pointer">
              Terms & Conditions
            </li>
            <li className="text-xs text-white cursor-pointer">Disclaimer</li>
            <li className="text-xs text-white cursor-pointer">Support</li>
            <li className="text-xs text-white cursor-pointer">Blog</li>
            <li className="text-xs text-white cursor-pointer">FAQ'S</li>
            <li className="copytext text-xs text-white font-bold pt-4">
              &copy; 2024 Poorvika Dairy
            </li>
          </ul>
        </div>
        <div className="w-1/4">
          <ul className="footertext m-0 p-0 list-none text-justify flex flex-col	gap-y-1.5  pl-10">
            <li className="text-lg text-white pt-28">
              <h1>Our Products</h1>
            </li>
            <li className="text-xs text-white cursor-pointer">A2 Milk</li>
            <li className="text-xs text-white cursor-pointer">A2 Paneer</li>
            <li className="text-xs text-white cursor-pointer">A2 Butter</li>
            <li className="text-xs text-white cursor-pointer">A2 Ghee</li>
          </ul>
        </div>
        <div className="w-1/4">
          <ul className="footertext m-0 p-0 list-none text-justify flex flex-col	gap-y-1.5  pl-10">
            <li className="text-lg text-white pt-28">
              <h1>Contact Us</h1>
            </li>
            <li className="text-xs text-white">Poorvika Dairy LLP,</li>
            <li className="text-xs text-white">32 Developed Plot Np,</li>
            <li className="text-xs text-white">Ekkattuthangal,</li>
            <li className="text-xs text-white">Chennai - 600032</li>
            <li className="text-xs underline decoration-white text-white cursor-pointer">
              Call +91 9566812345
            </li>
            <li className="text-xs underline decoration-white text-white cursor-pointer">
              E-Mail admin@poorvikadairy.in
            </li>
          </ul>
        </div>
        <div className="w-1/4">
          <ul className="footertext m-0 p-0 list-none text-justify flex flex-col	gap-y-1.5  pl-10 pr-10">
            <li className="text-lg text-white pt-28">
              <h1>STAY IN TOUCH</h1>
            </li>
            <li className="text-xs text-white">
              sign up for our newsletter to receive 20% off your first order!
            </li>
            <div className="flex gap-x-1.5">
              <button className="box1 py-3"></button>
              <button className="box2 text-xs font-bold py-3">Submit</button>
            </div>
            <li className="text-xs text-white">32 Developed Plot Np,</li>
            <li className="foottext text-xs text-white underline decoration-white">
              By signing up for our newsletter,you agree to our{" "}
              <span className="footspan">terms</span> and{" "}
              <span className="footspan">privacy policy.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}




