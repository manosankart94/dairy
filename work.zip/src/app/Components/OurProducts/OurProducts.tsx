import Link from "next/link";
import "./OurProducts.css";






export default function OurProducts() {
  return (
    <div className="mt-11">
      <div className="shoptext flex justify-center font-bold text-4xl">
        Shop Our Products
      </div>
      <div className="products m-auto	 mt-10 flex justify-around">
        <Link href="/LinkPage">
          <div className="w-64  product1 rounded-lg cursor-pointer pb-2.5 px-2.5">
            <img
              className="milk pt-2 m-auto pt-8"
              src="/3.png"
              alt="Milk"
            ></img>
            <div className="flex items-center">
              <img
                className="pl-2.5	pt-2.5 w-14"
                src="/21.png"
                alt="Reviews"
              ></img>
              <span className="review pl-2.5 pt-2.5 text-xs">2 Reviews</span>
            </div>
            <div className="milktext  font-bold pt-2.5 pl-2">A2 Milk</div>
            <div className="flex justify-between items-center">
              <div className="price m-2.5 flex justify-between items-center">
                <span className="inprice  font-bold">&#8377;40</span>
                <del className="delprice opacity-50 pl-2">&#8377;60</del>
              </div>
              <div className="ml m-2.5 flex justify-center items-center py-1">
                <span className="mlprice pt-1 text-xs font-normal">500ml</span>
                <span className="pl-1 flex">
                  <img src="/13.png"></img>
                </span>
              </div>
            </div>
            <div className="cart flex justify-between items-center">
              <div className=" button1 flex justify-around items-center m-2.5 py-2.5">
                <button className="subbutton justify-self-center">-</button>
                <div className="justify-self-center">5</div>
                <button className="addbutton justify-self-center">+</button>
              </div>
              <button className="button2 flex justify-center items-center m-1 rounded-lg">
                <img src="14.png" alt="cart"></img>
              </button>
            </div>
          </div>
        </Link>

        <div className="w-64 product1 rounded-lg pb-2.5 px-2.5">
          <img
            className="butter  m-auto pt-10"
            src="/4.png"
            alt="Butter"
          ></img>
          <div className="flex items-center">
            <img
              className="pl-2.5	pt-6 w-14"
              src="/21.png"
              alt="Reviews"
            ></img>
            <span className="review pl-2.5 pt-6 text-xs">2 Reviews</span>
          </div>
          <div className="milktext  font-bold pt-2.5 pl-2">A2 Butter</div>
          <div className="flex justify-between items-center">
            <div className="price m-2.5 flex justify-between items-center">
              <span className="inprice text-3xl font-bold">&#8377;40</span>
              <del className="delprice opacity-50 pl-2">&#8377;60</del>
            </div>
            <div className="ml m-2.5 flex justify-center items-center py-1">
              <span className="mlprice pt-1 text-xs font-normal">500ml</span>
              <span className="pl-1 flex">
                <img src="/13.png"></img>
              </span>
            </div>
          </div>
          <div className="cart flex justify-between items-center">
            <div className=" button1 flex justify-around items-center m-2.5 py-2.5">
              <button className="subbutton justify-self-center">-</button>
              <div className="justify-self-center">5</div>
              <button className="addbutton justify-self-center">+</button>
            </div>
            <button className="button2 flex justify-center items-center m-1 rounded-lg">
              <img src="14.png" alt="cart" className=""></img>
            </button>
          </div>
        </div>

        <div className="w-64 product1 rounded-lg pb-2.5 px-2.5 px-2.5">
          <img
            className="ghee pt-12 m-auto pt-11"
            src="/65.png"
            alt="Ghee"
          ></img>
          <div className="flex items-center">
            <img
              className="pl-2.5	pt-6 w-14"
              src="/21.png"
              alt="Reviews"
            ></img>
            <span className="review pl-2.5 pt-6 text-xs">2 Reviews</span>
          </div>
          <div className="milktext  font-bold pt-2.5 pl-2">A2 Ghee</div>
          <div className="flex justify-between items-center">
            <div className="price m-2.5 flex justify-between items-center">
              <span className="inprice text-3xl font-bold">&#8377;40</span>
              <del className="delprice opacity-50 pl-2">&#8377;60</del>
            </div>
            <div className="ml m-2.5 flex justify-center items-center py-1">
              <span className="mlprice pt-1 text-xs font-normal">500ml</span>
              <span className="pl-1 flex">
                <img src="/13.png"></img>
              </span>
            </div>
          </div>
          <div className="cart flex justify-between items-center">
            <div className=" button1 flex justify-around items-center m-2.5 py-2.5">
              <button className="subbutton justify-self-center">-</button>
              <div className="justify-self-center">5</div>
              <button className="addbutton justify-self-center">+</button>
            </div>
            <button className="button2 flex justify-center items-center m-1 rounded-lg">
              <img src="14.png" alt="cart" className=""></img>
            </button>
          </div>
        </div>

        <div className="w-64 product1 rounded-lg pb-2.5 px-2.5">
          <img
            className="paneer pt-10 m-auto pt-12"
            src="/6.png"
            alt="Paneer"
          ></img>
          <div className="flex items-center">
            <img
              className="pl-2.5 pt-8 w-14"
              src="/21.png"
              alt="Reviews"
            ></img>
            <span className="review pl-2.5 pt-8 text-xs">2 Reviews</span>
          </div>
          <div className="milktext  font-bold pt-2.5 pl-2">A2 Paneer</div>
          <div className="flex justify-between items-center">
            <div className="price m-2.5 flex justify-between items-center">
              <span className="inprice text-3xl font-bold">&#8377;40</span>
              <del className="delprice opacity-50 pl-2">&#8377;60</del>
            </div>
            <div className="ml m-2.5 flex justify-center items-center py-1">
              <span className="mlprice pt-1 text-xs font-normal">500ml</span>
              <span className="pl-1 flex">
                <img src="/13.png"></img>
              </span>
            </div>
          </div>
          <div className="cart flex justify-between items-center">
            <div className=" button1 flex justify-around items-center m-2.5 py-2.5">
              <button className="subbutton justify-self-center">-</button>
              <div className="justify-self-center">5</div>
              <button className="addbutton justify-self-center">+</button>
            </div>
            <button className="button2 flex justify-center items-center m-1 rounded-lg">
              <img src="14.png" alt="cart" className=""></img>
            </button>
          </div>
        </div>
      </div>
      <button className="viewproducts m-auto mt-14 flex justify-center items-center 	 rounded-lg py-4">
        View all products
        <span className="pl-1">
          <img src="/22.png" alt="arrow" className="pt-1 pl-1"></img>
        </span>
      </button>
    </div>
  );
}













