import "./Dairy.css";

function Dairy() {
  return (
    <div className="dairybanner  flex justify-around items-center  mt-10 text-justify">
      <div className="cowgif 	 w-2/5 relative">
        <img src="/15.gif" alt="Cow" className="cow pl-44" />

        <img src="/62.png" alt="grass" className="grass absolute"></img>
      </div>
      <div className="dairytext w-2/5  pt-14 pl-8">
        <div className="poortext  flex font-bold pl-16 pt-4">
          Poorvika Dairy
          <span>
            <img src="/16.png" alt="Flower" className="floima pl-2" />
          </span>
        </div>
        <div className="paratext text-black  text-2xl pl-16">
          We at Poorvika Dairy follow rich traditional practices with
          uncompromised quality,ensuring that we deliver Health and Happiness to
          all our Customers.
        </div>
        <div className="nattext text-2xl font-bold pt-3.5 pl-16">
          "Purity 0f Nature Quality of Motherhood"
        </div>
      </div>
      <div className="flowcontent ">
        <img src="/17.png" alt="Flower" className="floimage" />
      </div>
    </div>
  );
}

export default Dairy;










