import NavLeft from "./NavLeft";
import NavRight from "./NavRight";

export default function Nav() {
  return (
    // <div className="flex justify-between mt-5 bg-white">
    <div className="flex justify-around mt-5 bg-white">
      <NavLeft />
      <NavRight />
    </div>
  );
}



