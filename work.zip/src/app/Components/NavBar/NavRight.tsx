import Link from "next/link";

import "./NavRight.css";

export default function NavRight() {
  return (
    <div className="searchbox w-1/3	 flex justify-around  items-center">
      <form className="flex items-center   search_width">
        <div className="navform relative w-full rounded-lg">
          <input
            type="text"
            id="voice-search"
            className="navform bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full  p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            placeholder="Milk,Ghee,Butter etc..."
            required
          />
          <button
            type="button"
            className="navsearch absolute inset-y-0 end-0 flex items-center"
            style={{ padding: "10px", borderRadius: "5px" }}
          >
            <svg
              className="w-4 h-4 me-2"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 20 20"
              style={{ color: "#ffff" }}
            >
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
              />
            </svg>
          </button>
        </div>
      </form>

      <div className="profiletag relative">
        <img className="profile" src="/19.png" alt="profile"></img>
        <ul className="hoverprofile absolute w-48 h-32 rounded-xl">
          <Link href="AccountPage">
            <li className="account py-2.5 px-5">Your Orders</li>
          </Link>
          <li className="account py-2.5 px-5 font-bold">Account Settings</li>
          <li className="account py-2.5 px-5 font-bold">Logout</li>
        </ul>
      </div>
    </div>
  );
}






