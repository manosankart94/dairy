import Link from "next/link";

import "./NavLeft.css";

export default function NavLeft() {
  return (
    <div className="navleft w-2/4	 flex justify-between items-center">
      <Link href="/SubscribePage">
        <button className="subscribebutton flex justify-center	items-center ml-32  text-base rounded-md py-1.5">
          Subscribe A2 milk
        </button>
      </Link>
      <Link href="/HomePage">
        <img src="/47.png" alt="Dairy Logo" className="mr-5"></img>
      </Link>
    </div>
  );
}










