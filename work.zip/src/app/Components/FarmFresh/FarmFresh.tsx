import './Fresh.css';


export default function FarmFresh() {
    return (
        <div className="mt-52 banner">
             <div className="fresh bg-cover bg-repeat-x   relative">
                <div className="flex justify-center items-center"><img src="/25.png" alt="Farm Fresh" className="cowbanner absolute"></img></div>
            </div>
            <div className="freshy bg-cover bg-repeat-x  relative"></div>
            <button className="backbutton flex justify-center items-center rounded-lg relative py-3.5 text-center text-lg bg-white">Back to top<span className="pl-2"><img src="/64.png" alt="uparrow"></img></span></button>
        </div>

    );
  }


  
  

  