"use client";

import { url } from "inspector";
import "./Farming.css";
import Slider from "react-slick";

function Arrow(props: any) {
  let className = props.type === "next" ? "nextArrow" : "prevArrow";
  className += " arrow";
  const char =
    props.type === "next" ? <img src="/85.png" /> : <img src="/84.png" />;
  return (
    <span className={className} onClick={props.onClick}>
      {char}
    </span>
  );
}
var settings = {
  dots: true,
  infinite: false,
  speed: 500,
  slidesToShow: 3,
  slidesToScroll: 1,
  initialSlide: 0,
  responsive: [
    {
      breakpoint: 1000,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 1100,
      settings: {
        slidesToShow: 2,
      },
    },
  ],
};

// let width = screen.width;

// const settings = {
//   dots: true,
//   infinite: false,
//   speed: 500,
//   slidesToShow: 2,
//   slidesToScroll: 2,
// };

export default function Farming() {
  return (
    <div className="farm mt-12">
      <div className="exploresmall text-center  pt-24">Explore Our Farming</div>
      <div className="exploretext text-white text-center  font-bold">
        Explore Our Farming
      </div>
      <Slider
        className="slick-slider1 box-border"
        {...settings}
        nextArrow={<Arrow type="next" />}
        prevArrow={<Arrow type="prev" />}
      >
        {/* <div className="flex justify-center w-full"> */}
          <ul>
            <li className="slider1  rounded-3xl px-3.5 mb-1.5">
              <h1 className="header font-bold	text-2xl relative pl-2.5">
                Our Cattle Feed
              </h1>
              <p className="paragraph py-1.5	px-2.5 text-justify font-bold pt-20">
                Some of our cows feed is produced on our farm.Just like each of
                us, Our cows require a balanced diet, and each have their own
                individual meal plan, We change.
              </p>
              <button className="readbutton  py-3 px-5 ml-1.5  text-xs	text-center bg-white rounded-lg">
                Read More
              </button>
            </li>
          </ul>
          <ul>
            <li className="slider2  rounded-3xl px-3.5 mb-1.5">
              <h1 className="header font-bold	text-2xl relative pl-2.5">
                Visit Our Farm
              </h1>
              <p className="paragraph py-1.5	px-2.5 text-justify font-bold pt-20">
                Some of our cows feed is produced on our farm.Just like each of
                us, Our cows require a balanced diet, and each have their own
                individual meal plan, We change.
              </p>
              <button className="readbutton py-3 px-5 ml-1.5  text-xs	text-center bg-white rounded-lg">
                Read More
              </button>
            </li>
          </ul>
          <ul>
            <li className="slider3  rounded-3xl px-3.5 mb-1.5">
              <h1 className="header font-bold	text-2xl relative pl-2.5">
                Our Milk
              </h1>
              <p className="paragraph py-1.5	px-2.5 text-justify font-bold pt-20">
                Some of our cows feed is produced on our farm.Just like each of
                us, Our cows require a balanced diet, and each have their own
                individual meal plan, We change.
              </p>
              <button className="readbutton py-3 px-5 ml-1.5  text-xs	text-center bg-white rounded-lg">
                Read More
              </button>
            </li>
          </ul>
          <ul>
            <li className="slider4  rounded-3xl px-3.5 mb-1.5">
              <h1 className="header font-bold	text-2xl relative pl-2.5">
                Our Cattle
              </h1>
              <p className="paragraph py-1.5	px-2.5 text-justify font-bold pt-20">
                Some of our cows feed is produced on our farm.Just like each of
                us, Our cows require a balanced diet, and each have their own
                individual meal plan, We change.
              </p>
              <button className="readbutton py-3 px-5 ml-1.5  text-xs	text-center bg-white rounded-lg">
                Read More
              </button>
            </li>
          </ul>
        {/* </div> */}

        {/* <div
        className="demo123"
        style={{ width: "70%", margin: "auto", gap: "10px" }}
      >
        <Slider
          {...settings}

          className="slick-slider1 box-border"
          {...settings}
          nextArrow={<Arrow type="next" />}
          prevArrow={<Arrow type="prev" />}
        >


          <div className="slider-img">
            <h3 className="flex bg-amber-200	h-24 ">1</h3>
          </div>
          <div className="slider-img">
            <h3 className="flex bg-amber-700	h-24 	">2</h3>
          </div>
          <div className="slider-img">
            <h3 className="flex bg-lime-500	h-24 	">3</h3>
          </div>
          <div className="slider-img">
            <h3 className="flex bg-green-600	h-24 	">4</h3>
          </div>
          <div className="slider-img">
            <h3 className="flex bg-emerald-700	h-24 	">5</h3>
          </div>
        </Slider>
      </div> */}
      </Slider>
    </div>
  );
}





