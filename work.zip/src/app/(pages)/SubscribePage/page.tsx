"use client";
import React, { useState } from "react";

import Nav from "@/app/Components/NavBar/Nav";
import Products from "@/app/Components/Products/Products";
import "./Subscribe.css";

export default function Subscribe() {
  const MyForm = () => {
    const [formData, setFormData] = useState({
      firstName: "",
      lastName: "",
      mobileNumber: "",
      email: "",
      password: "",
    });
  };

  const handleChange = (e: { target: { name: any; value: any } }) => {
    const { name, value } = e.target;
  };

  const handleSubmit = (e: { preventDefault: () => void }) => {
    e.preventDefault();
  };

  return (
    <div>
      <Nav />
      <Products />
      <div className="packs pb-14">
        <div className="choosetext text-2xl	pt-28 pl-36">
          Choose your size(ml) &No.of Pacs
        </div>
        <div className="flex  justify-center items-center gap-x-5 box-border mt-10 ml-9 w-1/3">
          <div className="submilk  rounded-2xl py-4	px-6 bg-white">
            <img src="/63.png" alt="Milk" className="px-5	"></img>
            <p className="mltext text-center pt-6">
              1000ml<span className="rs">&#8377;80</span>
            </p>
            <p className="packtext text-center text-xs">No of packs</p>

            <div className="flex justify-around items-center pt-3.5 gap-3">
              <button className="packbuttons px-2.5	 py-1.5 text-center">
                -
              </button>
              <div>1</div>
              <button className="packbuttons px-2.5	 py-1.5	 text-center">
                +
              </button>
            </div>
          </div>
          <div className="submilk1 rounded-2xl py-4	px-6 bg-white">
            <img src="/63.png" alt="Milk" className="px-5	"></img>
            <p className="mltext text-center pt-6">
              500ml<span className="rs font-bold text-base">&#8377;80</span>
            </p>
            <p className="packtext text-center text-xs">No of packs</p>
            <div className="flex justify-around items-center pt-3.5 gap-3">
              <button className="packbuttons px-2.5	 py-1.5   text-center">
                -
              </button>
              <div>1</div>
              <button className="packbuttons px-2.5	 py-1.5 	text-center">
                +
              </button>
            </div>
          </div>
        </div>
        <p className="subtype  w-1/3 text-center pl-32 pt-10 font-bold">
          Choose your subscription type
        </p>
        <button className="onebuttonn flex justify-center items-center ml-40 mt-10  text-base rounded-lg relative py-2.5">
          Subscription
          <span className="pl-2">
            <img src="/69.png"></img>
          </span>
          <ul className="subscribe 	 bg-white absolute">
            <li className="subslist text-lg flex flex-col justify-center py-2">
              Subscription-Monthly
            </li>
            <li className="subslist text-lg flex flex-col justify-center py-2">
              Subscription-Weekly
            </li>
            <li className="subslist text-lg flex flex-col justify-center py-2">
              Subscription-Alternate Days
            </li>
            <li className="subslist text-lg flex flex-col justify-center py-2">
              Subscription-Choose Range
            </li>
          </ul>
        </button>
        <div className="subdays mt-8	flex  items-center gap-x-6 ml-40 w-full">
          <button className="day rounded-md py-1.5">S</button>
          <button className="day rounded-md py-1.5">M</button>
          <button className="day rounded-md py-1.5">T</button>
          <button className="day rounded-md py-1.5">W</button>
          <button className="day rounded-md py-1.5">T</button>
          <button className="day rounded-md py-1.5">F</button>
          <button className="day rounded-md py-1.5">S</button>
        </div>

        <div className="">
          <h1 className="perdetails pt-12 text-center   text-3xl">
            Personal Details
          </h1>

          <div className="formcon">
            <form className="forms  m-auto" onSubmit={handleSubmit}>
              <div className="flex mt-6">
                <div className="w-2/4">
                  <div>
                    <label htmlFor="firstName" className="label text-lg">
                      First Name
                    </label>
                  </div>
                  <div className="">
                    <input
                      type="text"
                      name="firstName"
                      onChange={handleChange}
                      className="form py-2.5 rounded px-2.5"
                    />
                  </div>
                </div>
                <div className="w-2/4">
                  <div>
                    <label htmlFor="lastName" className="label text-lg">
                      Last Name
                    </label>
                  </div>
                  <div>
                    <input
                      type="text"
                      name="lasttName"
                      onChange={handleChange}
                      className="form1 py-2.5 rounded px-2.5"
                    />
                  </div>
                </div>
              </div>

              <div className="bordersub flex   mt-10">
                <div className="w-2/4">
                  <div>
                    <label htmlFor="mobilenumber" className="label text-lg">
                      Mobile Number
                    </label>
                  </div>
                  <div>
                    <input
                      type="number"
                      name="mobile number"
                      onChange={handleChange}
                      className="form py-2.5 rounded px-2.5"
                    />
                  </div>
                </div>
                <div className="w-2/4">
                  <div>
                    <label htmlFor="firstName" className="label text-lg">
                      Email
                    </label>
                  </div>
                  <div>
                    <input
                      type="email"
                      name="email"
                      onChange={handleChange}
                      className="form1 py-2.5 rounded px-2.5"
                    />
                  </div>
                </div>
              </div>

              <div>
                <div>
                  <h1 className="delivery flex items-center mt-10 text-3xl">
                    Setup your delivery Address
                    <span className="ml-6 flex items-center justify-between">
                      <button className="locationbutton  rounded-md	 flex  text-lg items-center  px-4 py-1">
                        <img src="/94.png" className="pr-2"></img>Detect my
                        Location
                      </button>
                    </span>
                  </h1>
                </div>
                <div>
                  <div className="mt-10">
                    <label htmlFor="address" className="label text-lg">
                      Address
                    </label>
                  </div>
                  <div>
                    <textarea
                      name="address"
                      onChange={handleChange}
                      placeholder="Enter your detailed address here"
                      className="formadd py-7 pl-6 rounded px-2.5"
                    />
                  </div>

                  <div className="flex mt-6">
                    <div className="w-2/4">
                      <div>
                        <label htmlFor="villaname" className="label text-lg">
                          VillaName/PlotName
                        </label>
                      </div>
                      <div className="">
                        <input
                          type="text"
                          name="villaName"
                          onChange={handleChange}
                          className="form py-2.5 rounded px-2.5"
                        />
                      </div>
                    </div>
                    <div className="w-2/4">
                      <div>
                        <label htmlFor="villaname" className="label text-lg">
                          VillaNo/PlotNo
                        </label>
                      </div>
                      <div>
                        <input
                          type="number"
                          name="villaName"
                          onChange={handleChange}
                          className="form1 py-2.5 rounded px-2.5"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex mt-6">
                    <div className="w-2/4">
                      <div>
                        <label htmlFor="area" className="label text-lg">
                          Area
                        </label>
                      </div>
                      <div className="">
                        <input
                          type="text"
                          name="area"
                          onChange={handleChange}
                          className="form py-2.5 rounded px-2.5"
                        />
                      </div>
                    </div>
                    <div className="w-2/4">
                      <div>
                        <label htmlFor="pincode" className="label text-lg">
                          Pin Code
                        </label>
                      </div>
                      <div>
                        <input
                          type="number"
                          name="Pincode"
                          onChange={handleChange}
                          className="form1 py-2.5 rounded px-2.5"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex mt-6">
                    <div className="w-2/4">
                      <div>
                        <label htmlFor="state" className="label text-lg">
                          State
                        </label>
                      </div>
                      <div className="">
                        <input
                          type="text"
                          name="state"
                          onChange={handleChange}
                          className="form py-2.5 rounded px-2.5"
                        />
                      </div>
                    </div>
                    <div className="w-2/4">
                      <div>
                        <label htmlFor="lastName" className="label text-lg">
                          City
                        </label>
                      </div>
                      <div>
                        <input
                          type="text"
                          name="city"
                          onChange={handleChange}
                          className="form1 py-2.5 rounded px-2.5"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex mt-6">
                    <div className="w-2/4">
                      <div>
                        <label htmlFor="country" className="label text-lg">
                          Country
                        </label>
                      </div>
                      <div className="">
                        <input
                          type="text"
                          name="country"
                          onChange={handleChange}
                          className="form py-2.5 rounded px-2.5" 
                        />
                      </div>
                    </div>
                    <div className="w-2/4">
                      <div>
                        <label htmlFor="lastName" className="label text-lg">
                          LandMark
                        </label>
                      </div>
                      <div>
                        <input
                          type="text"
                          name="milk,ghee,butter"
                          onChange={handleChange}
                          placeholder="Milk,Ghee,Butter etc."
                          className="form1 py-2.5 rounded px-2.5"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex mt-6">
                    <div className="w-2/4">
                      <div>
                        <label
                          htmlFor="deliveryinstruction"
                          className="label text-lg"
                        >
                          Delivery Instruction(Optional)
                        </label>
                      </div>
                      <div className="">
                        <input
                          type="text"
                          name="firstName"
                          onChange={handleChange}
                          className="form py-2.5 rounded px-2.5"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex mt-10">
                    <label  className="bell text-xl 	 text-lg flex justify-around items-center">
                      <input
                        type="radio" className="radiotext"
                        value="option1"
                        onChange={handleChange}
                      />
                      Don't ring the Bell
                    </label>

                    <label className="parsecurity pl-6 text-xl w-1/5	 text-lg  flex justify-between items-center">
                      <input
                        type="radio" className="radiotextt"
                        value="option2"
                        onChange={handleChange}
                      />
                      Give the parcel to security
                    </label>
                  </div>
                  <button className="formsub text-lg rounded-lg mt-10 decoration-white	 text-center py-3 bg-lime-500 w-1/5">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}





