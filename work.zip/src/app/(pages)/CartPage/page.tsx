"use client";
import Nav from "@/app/Components/NavBar/Nav";
import "./Cart.css";
import { useState } from "react";

export default function Cart() {
  const [checkOut, setCheckOut] = useState(false);

  const handleCheckout = () => {
    setCheckOut(true);
  };
  return (
    <div>
      <Nav />
      <div className="milkimage bg-cover box-border text-3xl font-bold pt-20 pb-5 mt-5 bg-no-repeat">
        CheckOut
      </div>

      {checkOut ? (
        <div className="checkoutbanner flex justify-center gap-x-8 pb-44">
          <div className="checkleft w-2/4">
            <button className="checkoutcart w-full flex justify-between items-center bg-white relative py-2.5 text-2xl pl-2.5 rounded-lg">
              cart
              <button className="checkbutton absolute mr-2.5 rounded text-sm py-1">
                Edit
              </button>
            </button>
            <button className="checkoutcart w-full flex justify-start bg-white py-2.5 text-2xl pl-2.5 rounded-lg mt-5">
              Choose Your Delivery Address
            </button>
            <p className="cartaddress w-full text-center text-sm  pt-8">
              You didn't saved any address,kindly add new address to continue.
            </p>
            <p className="cartaddresss w-full text-center text-sm  pt-8">
              Add New Address +
            </p>
            <button className="checkoutcart w-full flex justify-start bg-white py-2.5 text-2xl pl-2.5 rounded-lg mt-5">
              Order Summary
            </button>
            <button className="checkoutcart w-full flex justify-start bg-white py-2.5 text-2xl pl-2.5 rounded-lg mt-5">
              Choose Your Payment Method
            </button>
          </div>
          <div className="checkright bg-white mr-5 rounded-2xl w-1/4">
            <p className="pricedetails text-center pt-2.5 text-2xl">
              Price Details
            </p>
            <div className="flex justify-between items-center">
              <div className="cartone flex items-center w-2/4">
                <div className="ml-2.5 mt-2.5">
                  <img src="/97.png" alt="milk" />
                </div>
                <p className="cartml pl-5 flex flex-col font-bold">
                  A2 Milk<span className="text-xs">(500ml)</span>
                </p>
              </div>
              <div className="carttwo text-center pt-3 w-1/5">&#215;1</div>
              <div className="cartthree text-center pt-3 w-1/5"> &#8377;80</div>
            </div>
            <div className="flex justify-between items-center">
              <div className="cartone flex items-center w-2/4">
                <div className="ml-2.5 mt-2.5">
                  <img src="/97.png" alt="milk" />
                </div>
                <p className="cartml pl-5 flex flex-col font-bold">
                  A2 Milk<span className="text-xs">(500ml)</span>
                </p>
              </div>
              <div className="carttwo text-center pt-3 w-1/5">&#215;1</div>
              <div className="cartthree text-center pt-3 w-1/5"> &#8377;80</div>
            </div>
            <div className="cartcoupon w-full flex justify-around mt-5">
              <form>
                <div>
                  <input
                    type="number"
                    name="coupon code"
                    // onChange={handleChange}
                    className="coupon w-full py-2.5 rounded px-2.5"
                    placeholder="Enter Coupon Code"
                  />
                </div>
              </form>
              <button className="cartapply py-2.5 text-white">Apply</button>
            </div>
            <div className="mx-6 ">
              <div className="flex justify-between items-around pt-5">
                <div className="carttext text-lg">Discount</div>
                <div className="carttext text-lg">-</div>
              </div>
              <div className="flex justify-between items-around pt-5">
                <div className="carttext text-lg">Delivery Charge</div>
                <div className="cartfree text-lg">Free</div>
              </div>
              <div className="cartborder flex justify-between items-around pt-5 pb-3">
                <div className="carttext text-lg">Incl GST12%</div>
                <div className="carttext text-lg">&#8377;14</div>
              </div>
              <div className="flex justify-between items-around pt-5 pb-3.5">
                <div className="carttext text-lg">Total Amount</div>
                <div className="cartfreeamount text-2xl font-bold">
                  &#8377;174
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="cartbanner flex justify-center pb-28">
          <div className="cartleft w-3/5  rounded mt-10">
            <div>
              <div className="cart1 flex justify-between pb-6 bg-white rounded-lg pb-2.5">
                <div className="flex w-2/4">
                  <div className="w-2/5">
                    <div className="cartmilker flex justify-center py-5 mt-6 ml-6 rounded-lg">
                      <img
                        src="/95.png"
                        className="cartpanner"
                        alt="panner"
                      ></img>
                    </div>
                    <h4 className="text-center text-xs pt-6">No.of packs</h4>
                    <div className="flex justify-around items-center">
                      <button className="cartadding text-center py-1.5 px-3 text-2xl">
                        -
                      </button>
                      <div className="">1</div>
                      <button className="cartadding text-center py-1.5 px-3 text-2xl">
                        +
                      </button>
                    </div>
                  </div>
                  <div className="w-3/5">
                    <p className="carttextmilk font-bold text-xl pt-4 pl-6">
                      A2 Paneer
                    </p>
                    <p className="cartquantitytext text-sm pt-1.5 pl-6">
                      Quantity
                    </p>
                    <button className="cartquantity flex items-center justify-center text-xs mt-3 py-1.5 rounded-sm relative box-border ml-6">
                      500ml
                      <span>
                        <img
                          src="/69.png"
                          alt="dropdown"
                          className="pl-1"
                        ></img>
                      </span>
                      <div className="absolute w-full">
                        <ul className="innerquantity rounded-sm hidden pb-4 mt-16">
                          <li>1000ml</li>
                        </ul>
                      </div>
                    </button>
                    <div className="cartprice flex items-center">
                      <div className="rupees text-3xl font-bold pl-6">
                        &#8377;40
                        <del className="deletepricee text-xl opacity-80 pl-4">
                          &#8377;60
                        </del>
                      </div>
                      <div className="freedelivery pl-10 pt-6 text-sm">
                        Free Delivery
                      </div>
                    </div>
                    <button className="onebuttoncart bg-white flex  items-center ml-6 justify-center mt-4  text-base rounded-lg relative py-2.5 w-3/4">
                      Subscription
                      <span className="pl-2">
                        <img src="/69.png"></img>
                      </span>
                      <ul className="subscribe 	 bg-white absolute">
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Monthly
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Weekly
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Alternate Days
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Choose Range
                        </li>
                      </ul>
                    </button>
                  </div>
                </div>
                <div className="cartremove flex justify-center items-center rounded mr-6 mt-4">
                  <div>
                    <img src="/87.png" alt="trash"></img>
                  </div>
                  <div className="text-xs pl-4">Remove</div>
                </div>
              </div>

              <div className="cart2 flex justify-between  mt-10 bg-white rounded-lg pb-2.5">
                <div className="flex w-2/4">
                  <div className="w-2/5">
                    <div className="cartmilker flex justify-center py-5 mt-6 ml-6 rounded-lg">
                      <img src="/96.png" className="w-2/4" alt="panner"></img>
                    </div>
                    <h4 className="text-center text-xs pt-6">No.of packs</h4>
                    <div className="flex justify-around items-center">
                      <button className="cartadding text-center py-1.5 px-3 text-2xl">
                        -
                      </button>
                      <div className="">1</div>
                      <button className="cartadding text-center py-1.5 px-3 text-2xl">
                        +
                      </button>
                    </div>
                  </div>
                  <div className="w-3/5">
                    <p className="carttextmilk font-bold text-xl pt-4 pl-6">
                      A2 Milk
                    </p>
                    <p className="cartquantitytext text-sm pt-1.5 pl-6">
                      Quantity
                    </p>
                    <button className="cartquantity flex items-center justify-center text-xs mt-3 py-1.5 rounded-sm relative box-border ml-6">
                      500ml
                      <span>
                        <img
                          src="/69.png"
                          alt="dropdown"
                          className="pl-1"
                        ></img>
                      </span>
                      <div className="absolute w-full">
                        <ul className="innerquantity  rounded-sm hidden pb-4 mt-16">
                          <li>1000ml</li>
                        </ul>
                      </div>
                    </button>
                    <div className="cartprice flex items-center">
                      <div className="rupees text-3xl font-bold pl-6">
                        &#8377;40
                        <del className="deletepricee text-xl opacity-80 pl-4">
                          &#8377;60
                        </del>
                      </div>
                      <div className="freedelivery pl-10 pt-6 text-sm">
                        Free Delivery
                      </div>
                    </div>
                    <button className="onebuttoncart bg-white flex  items-center ml-6 justify-center mt-4  text-base rounded-lg relative py-2.5 w-3/4">
                      Subscription
                      <span className="pl-2">
                        <img src="/69.png"></img>
                      </span>
                      <ul className="subscribe 	 bg-white absolute">
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Monthly
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Weekly
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Alternate Days
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Choose Range
                        </li>
                      </ul>
                    </button>
                  </div>
                </div>
                <div className="cartremove flex justify-center items-center rounded mr-6 mt-4">
                  <div>
                    <img src="/87.png" alt="trash"></img>
                  </div>
                  <div className="text-xs pl-4">Remove</div>
                </div>
              </div>

              <div className="cart2 flex justify-between  mt-10 bg-white rounded-lg pb-2.5">
                <div className="flex w-2/4">
                  <div className="w-2/5">
                    <div className="cartmilker flex justify-center py-5 mt-6 ml-6 rounded-lg">
                      <img src="/96.png" className="w-2/4" alt="panner"></img>
                    </div>
                    <h4 className="text-center text-xs pt-6">No.of packs</h4>
                    <div className="flex justify-around items-center">
                      <button className="cartadding text-center py-1.5 px-3 text-2xl">
                        -
                      </button>
                      <div className="">1</div>
                      <button className="cartadding text-center py-1.5 px-3 text-2xl">
                        +
                      </button>
                    </div>
                  </div>
                  <div className="w-3/5">
                    <p className="carttextmilk font-bold text-xl pt-4 pl-6">
                      A2 Milk
                    </p>
                    <p className="cartquantitytext text-sm pt-1.5 pl-6">
                      Quantity
                    </p>
                    <button className="cartquantity flex items-center justify-center text-xs mt-3 py-1.5 rounded-sm relative box-border ml-6">
                      500ml
                      <span>
                        <img
                          src="/69.png"
                          alt="dropdown"
                          className="pl-1"
                        ></img>
                      </span>
                      <div className="absolute w-full">
                        <ul className="innerquantity  rounded-sm hidden pb-4 mt-16">
                          <li>1000ml</li>
                        </ul>
                      </div>
                    </button>
                    <div className="cartprice flex items-center">
                      <div className="rupees text-3xl font-bold pl-6">
                        &#8377;40
                        <del className="deletepricee text-xl opacity-80 pl-4">
                          &#8377;60
                        </del>
                      </div>
                      <div className="freedelivery pl-10 pt-6 text-sm">
                        Free Delivery
                      </div>
                    </div>
                    <button className="onebuttoncart bg-white flex  items-center ml-6 justify-center mt-4  text-base rounded-lg relative py-2.5 w-3/4">
                      Subscription
                      <span className="pl-2">
                        <img src="/69.png"></img>
                      </span>
                      <ul className="subscribe 	 bg-white absolute">
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Monthly
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Weekly
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Alternate Days
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Choose Range
                        </li>
                      </ul>
                    </button>
                  </div>
                </div>
                <div className="cartremove flex justify-center items-center rounded mr-6 mt-4">
                  <div>
                    <img src="/87.png" alt="trash"></img>
                  </div>
                  <div className="text-xs pl-4">Remove</div>
                </div>
              </div>

              <div className="cart2 flex justify-between  mt-10 bg-white rounded-lg pb-2.5">
                <div className="flex w-2/4">
                  <div className="w-2/5">
                    <div className="cartmilker flex justify-center py-3 mt-6 ml-6 rounded-lg">
                      <img src="/96.png" className="w-2/4" alt="panner"></img>
                    </div>
                    <h4 className="text-center text-xs pt-6">No.of packs</h4>
                    <div className="flex justify-around items-center">
                      <button className="cartadding text-center py-1.5 px-3 text-2xl">
                        -
                      </button>
                      <div className="">1</div>
                      <button className="cartadding text-center py-1.5 px-3 text-2xl">
                        +
                      </button>
                    </div>
                  </div>
                  <div className="w-3/5">
                    <p className="carttextmilk font-bold text-xl pt-4 pl-6">
                      A2 Milk
                    </p>
                    <p className="cartquantitytext text-sm pt-1.5 pl-6">
                      Quantity
                    </p>
                    <button className="cartquantity flex items-center justify-center text-xs mt-3 py-1.5 rounded-sm relative box-border ml-6">
                      500ml
                      <span>
                        <img
                          src="/69.png"
                          alt="dropdown"
                          className="pl-1"
                        ></img>
                      </span>
                      <div className="absolute w-full">
                        <ul className="innerquantity  rounded-sm hidden pb-4 mt-16">
                          <li>1000ml</li>
                        </ul>
                      </div>
                    </button>
                    <div className="cartprice flex items-center">
                      <div className="rupees text-3xl font-bold pl-6">
                        &#8377;40
                        <del className="deletepricee text-xl opacity-80 pl-4">
                          &#8377;60
                        </del>
                      </div>
                      <div className="freedelivery pl-10 pt-6 text-sm">
                        Free Delivery
                      </div>
                    </div>
                    <button className="onebuttoncart bg-white flex  items-center ml-6 justify-center mt-4  text-base rounded-lg relative py-2.5 w-3/4">
                      Subscription
                      <span className="pl-2">
                        <img src="/69.png"></img>
                      </span>
                      <ul className="subscribe 	 bg-white absolute">
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Monthly
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Weekly
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Alternate Days
                        </li>
                        <li className="subslist text-lg flex flex-col justify-center py-2">
                          Subscription-Choose Range
                        </li>
                      </ul>
                    </button>
                  </div>
                </div>
                <div className="cartremove flex justify-center items-center rounded mr-6 mt-4">
                  <div>
                    <img src="/87.png" alt="trash"></img>
                  </div>
                  <div className="text-xs pl-4">Remove</div>
                </div>
              </div>
            </div>
          </div>

          <div className="cartright ml-10 mt-24 rounded-xl w-1/4 bg-white">
            <div className="cartdetail pt-6 text-center text-xl font-bold">
              PRICE DETAILS
            </div>
            <div className="flex justify-between items-center pt-6">
              <div className="pl-6">Total price(2 items)</div>
              <div className="pr-4">&#8377;2220</div>
            </div>
            <div className="flex justify-between items-center pt-6">
              <form>
                <div>
                  <input
                    type="number"
                    name="mobile number"
                    className="formcart py-2.5 ml-6 py-2.5 pl-2.5"
                    placeholder="Enter Coupon Code"
                  />
                </div>
              </form>
              <button className="formcartbutton text-center mr-2 w-1/5 py-2.5 text-white">
                Apply
              </button>
            </div>
            <div className="flex justify-between items-center pt-6">
              <div className="pl-6">Discount</div>
              <div className="pr-4 text-3xl">-</div>
            </div>
            <div className="flex justify-between items-center pt-6">
              <div className="pl-6">Delivery Charge</div>
              <div className="cartfree font-bold pr-4">Free</div>
            </div>
            <div className="cartborder flex justify-between items-center pt-6 pb-6">
              <div className="pl-6">Incl GST 12%</div>
              <div className="pr-4">&#8377;14</div>
            </div>
            <div className="cartborder flex justify-between items-center pt-6 pb-6">
              <div className="pl-6">Total Amount</div>
              <div className="cartfree font-bold pr-4">&#8377;120</div>
            </div>
            <button
              className="cartcheckout rounded-lg text-white py-5 w-full"
              onClick={handleCheckout}
            >
              Checkout
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
