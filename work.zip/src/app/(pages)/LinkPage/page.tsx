import Nav from "@/app/Components/NavBar/Nav";
import "./Link.css";
import Products from "@/app/Components/Products/Products";

function LinkElement() {
  return (
    <div>
      <Nav />
      <Products />
      <div className="linkcontainer 	flex">
        <div className="a2left  mt-14">
          <div className="milkimagee  ml-28 flex justify-center rounded-lg py-2.5">
            <img src="/37.png" className="px-20 py-6"></img>
          </div>
          <div className="flex justify-center gap-x-2.5 mt-6 ml-32">
            <div className="smallmilkimg rounded-lg w-1/5">
              <img src="/36.png" className="px-3 py-2.5"></img>
            </div>
            <div className="smallmilkimg rounded-lg">
              <img src="/36.png" className="px-3 py-2.5"></img>
            </div>
            <div className="smallmilkimg rounded-lg">
              <img src="/36.png" className="px-3 py-2.5"></img>
            </div>
          </div>
        </div>
        <div className="a2right">
          <header className="milktextt text-3xl font-bold pt-2.5 pl-14 pt-12">
            A2 Milk
          </header>
          <p className="textquantity pl-14 pt-5">Quantity</p>
          <div className="flex">
            <button className="ml ml-14 mt-5 flex items-center justify-center rounded-lg text-sm">
              500ml
              <span>
                <img src="/39.png" alt="Dropdown" className="pl-2" />
              </span>
            </button>
            <div className="rupee text-4xl font-bold pl-5 pt-5">
              &#8377;40
              <del className="delpricee text-3xl opacity-80 pl-4">
                <sup>&#8377;60</sup>
              </del>
            </div>
          </div>
          <p className="producttext pl-14 pt-6">Product Description</p>
          <p className="longtext pl-14 pt-6 text-lg w-8/12 text-sm">
            Pure A2 Gir Cow milk from our own farm.Hi-techdairy farms where we
            ensure cow comfort,hygiene,health and high quality feed grew by us
            using our own cow manure.Our 24 &#215;7 vet doctors and nutritionist
            ensure cow health.
          </p>
          <button className="onebutton flex justify-center items-center ml-14 mt-10  text-2xl rounded-lg relative py-2.5 w-2/5">
            OneTime
            <span className="pl-6">
              <img src="/38.png"></img>
            </span>
            <ul className="subscribee 	bg-white absolute rounded-xl w-full">
              <li className="subslistt text-2xl flex flex-col justify-center pt-3.5">
                Subscription-Monthly
              </li>
              <li className="subslistt text-2xl flex flex-col justify-center pt-3.5">
                Subscription-Weekly
              </li>
              <li className="subslistt text-2xl flex flex-col justify-center pt-3.5">
                Subscription-Alternate Days
              </li>
              <li className="subslistt text-2xl flex flex-col justify-center pt-3.5">
                Subscription-Choose Range
              </li>
            </ul>
          </button>
          <p className="pl-14 pt-10">No.of.pacs</p>
          <div className="flex items-center ml-14 gap-x-7 mt-2.5">
            <button className="decrementbutton w-8	h-7 py-2.5   flex justify-center items-center text-2xl">
              -
            </button>
            <div className="text-2xl">1</div>
            <button className="incrementbutton w-8	h-7 py-2.5 flex justify-center items-center  text-2xl">
              +
            </button>
          </div>
          <div className="flex ml-14 mt-10 gap-x-3">
            <button className="cartbutton rounded-lg font-bold text-xl w-2/5 py-4">
              Add To Cart
            </button>
            <button className="buybutton rounded-lg font-bold text-xl w-1/4 py-4">
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LinkElement;
