import Nav from "@/app/Components/NavBar/Nav";
import OurProducts from "@/app/Components/OurProducts/OurProducts";
import Products from "@/app/Components/Products/Products";
import FarmFresh from "@/app/Components/FarmFresh/FarmFresh";
import Footer from "@/app/Components/Footer/Footer";
import Dairy from "@/app/Components/Dairy/Dairy";
import MilkBanner from "@/app/Components/MilkBanner/MilkBanner";
import Carousel from "@/app/Components/Carousel/Carousel";
import Farming from "@/app/Components/Farming/Farming";


export default function Home() {
    return (
      <div>
        <Nav />
        <Products />
        <Carousel />
        <OurProducts />
        <Farming />
        <MilkBanner />
        <Dairy />
        <FarmFresh />
        <Footer />
      </div>
    );
  }
