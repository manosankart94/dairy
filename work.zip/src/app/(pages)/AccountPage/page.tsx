"use client";
import Link from "next/link";
import { useState } from "react";

import Nav from "@/app/Components/NavBar/Nav";
import "./Accounts.css";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";

function Account() {
  const [tab1, setTab1] = useState(false);
  const [tab2, setTab2] = useState(true);

  const subpage = () => {
    setTab1(true);
    setTab2(false);
  };

  const subpage1 = () => {
    setTab1(false);
    setTab2(true);
  };
  return (
    <div className="whole">
      <Nav />
      <div className="milkimage bg-cover box-border text-3xl font-bold pt-12 pl-44  bg-no-repeat">
        Your Orders
      </div>
      <div className="flex">
        <div
          className="onetime w-2/4 	flex justify-center text-2xl pt-3 pb-3 cursor-pointer"
          onClick={subpage1}
        >
          One time Orders
        </div>
        <div
          className="milksubs w-2/4  flex justify-center text-2xl pt-3 pb-3 cursor-pointer"
          onClick={subpage}
        >
          A2 Milk Subscriptions
        </div>
      </div>

      {tab1 && (
        <div>
          <div className="milksubscription">
            <div className="accountbanners flex">
              <div className="acco my-2.5 w-full">
                <div className="flex items-center justify-center">
                  <div className="recent text w-9/12	text-xl font-semibold pt-4 pl-4">
                    Recent Subscriptions
                  </div>
                  <div className="history w-3/12	 flex items-center justify-end pr-6 pt-8">
                    <img src="/71.png" alt="order History"></img>
                    <Link href="OrderHistory">
                      <span className="ordertext pl-1.5 text-base font-semibold">
                        Order History
                      </span>
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            <div className="subpanel flex justify-between  m-auto pb-20 mt-10">
              <div className="subleft w-2/5">
                <div className="subbanner flex pb-6 w-9/12 ml-12">
                  <div className="imgmilk mt-8 w-2/5">
                    <img src="/74.png"></img>
                  </div>
                  <div className="imgtext w-3/5">
                    <p className="textmilk text-3xl font-bold flex items-center pl-2.5 pt-8">
                      A2 Milk
                      <span className="halftext text-xl pt-0.5 pl-1.5">
                        500ml
                      </span>
                    </p>
                    <p className="pacs pl-2.5 pt-2">1pacs(28 Days)</p>
                    <button className="monsubs  rounded-lg ml-2.5 font-bold mt-2 py-2.5 px-3">
                      Monthly Subscription
                    </button>
                    <p className="del pl-2.5 pt-2">Delivery starts on 03 Apr</p>
                  </div>
                </div>
                <div className="check pb-6 w-3/4 ml-12">
                  <p className="status pt-6 font-bold pl-12">STATUS:</p>
                  <div className="flex items-center">
                    <button className="deliverbutton font-bold mt-5 ml-14 py-2.5 px-6 text-xs">
                      Delivered
                      <span className="num pl-2 font-bold text-xs">10</span>
                    </button>
                    <button className="pendingbutton font-bold mt-5 ml-3 rounded py-2.5 px-6 text-xs">
                      Pending<span className="num1 pl-2 font-bold">26</span>
                    </button>
                    <button className="holdingbutton font-bold mt-5 ml-3 py-2.5 px-6 text-xs">
                      Holding<span className="num2 pl-2 font-bold">0</span>
                    </button>
                  </div>
                </div>
                <div className="flex">
                  <button className="subcancelbutton mt-8 ml-12 rounded font-bold  py-2.5 px-6 text-xs">
                    Cancel Subscription
                  </button>
                  <button className="viewsubbutton mt-8 ml-6 rounded font-bold py-2.5 px-6 text-xs">
                    View Subscription Details
                  </button>
                </div>
              </div>
              <div className="calendar-container">
                <Calendar value={new Date()} />
              </div>
            </div>
          </div>
        </div>
      )}

      {tab2 && (
        <>
          <div className="accountbanners flex">
            <div className="acco my-2.5 w-full">
              <div className="flex items-center justify-center">
                <div className="recenttext w-9/12	text-xl font-semibold pt-10 pl-16">
                  Recent Subscriptions
                </div>
                <div className="history w-3/12	 flex items-center justify-end pt-6">
                  <img src="/71.png" alt="order History"></img>
                  <Link href="OrderHistory">
                    <span className="ordertext pl-1.5 text-base font-semibold">
                      Order History
                    </span>
                  </Link>
                </div>
              </div>
            </div>
          </div>

          <div className="orderpage py-6">
            <div className="flexorder m-auto flex w-10/12 bg-white">
              <div className="orderleft flex justify-center items-center py-2.5 m-5">
                <img src="/72.png" alt="milk"></img>
              </div>
              <div className="orderright w-10/12 pb-10">
                <div className="flex justify-between">
                  <div className="">
                    <p className="a2text text-2xl pt-4">
                      A2 Milk<span className="mltext px-2 text-lg">500ml</span>
                    </p>
                    <p className="packtext">2 packs</p>
                  </div>
                  <div>
                    <button className="canbutton text-center mr-12 text-sm text-center rounded font-medium py-2.5 mt-5 w-28">
                      Cancel Order
                    </button>
                    <button className="vieworderbutton text-center mr-12 text-sm text-center rounded font-medium py-2.5 mt-5 w-36">
                      View Order Details
                    </button>
                  </div>
                </div>
                <div>
                  <ul className="listorder relative w-3/4 h-0.5 ml-8 mt-8">
                    <li className="order1 absolute w-5 h-5"></li>
                    <li className="order2 absolute w-5 h-5"></li>
                    <li className="order33 absolute w-5 h-5"></li>
                    <li className="order44 absolute w-5 h-5"></li>
                    <li className="order55 absolute w-5 h-5"></li>
                  </ul>
                </div>

                <div>
                  <ul className="listorderr relative w-3/4 h-0.5 m-8 mt-8">
                    <li className="orderr1 absolute text-center">
                      <p className="recorder text-sm font-bold">
                        Order Received
                      </p>
                      <p className="smalltext text-xs">Order Received on</p>
                      <p className="smalltext text-xs">25 May 7AM</p>
                    </li>
                    <li className="orderr2 absolute text-center">
                      <p className="recorderr text-sm font-bold">
                        Order Confirmed
                      </p>
                      <p className="smalltextt text-xs">Order Confirmed on</p>
                      <p className="smalltextt text-xs">25 May 7AM</p>
                    </li>
                    <li className="orderr3 absolute text-center">
                      <p className="recorderr text-sm font-bold">
                        Order Shipped
                      </p>
                      <p className="smalltextt text-xs">Order Shipped on</p>
                      <p className="smalltextt text-xs">25 May 7AM</p>
                    </li>
                    <li className="orderr4 absolute text-center">
                      <p className="recorderr text-sm font-bold">
                        Out For Delivery
                      </p>
                      <p className="smalltextt text-xs">Order Shipped on</p>
                      <p className="smalltextt text-xs">25 May 7AM</p>
                    </li>
                    <li className="orderr5 absolute text-center">
                      <p className="recorderr text-sm font-bold">Delivered</p>
                      <p className="smalltextt text-xs">Expected Delivery On</p>
                      <p className="smalltextt text-xs">25 May 7AM</p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="orderpage py-6">
            <div className="flexorder m-auto flex w-10/12 bg-white">
              <div className="orderleft flex justify-center items-center py-2.5 m-5 pb-10">
                <img src="/72.png" alt="milk"></img>
              </div>
              <div className="orderright w-10/12">
                <div className="flex justify-between">
                  <div className="">
                    <p className="a2text text-2xl pt-4">
                      A2 Milk<span className="mltext px-2 text-lg">500ml</span>
                    </p>
                    <p className="packtext">2 packs</p>
                  </div>
                  <div>
                    <button className="canbutton text-center mr-12 text-sm text-center rounded font-medium py-2.5 mt-5 w-28">
                      Cancel Order
                    </button>
                    <button className="vieworderbutton text-center mr-12 text-sm text-center rounded font-medium py-2.5 mt-5 w-36">
                      View Order Details
                    </button>
                  </div>
                </div>
                <div>
                  <ul className="listorder relative w-3/4 h-0.5 ml-8 mt-8">
                    <li className="order1 absolute w-5 h-5"></li>
                    <li className="order2 absolute w-5 h-5"></li>
                    <li className="order33 absolute w-5 h-5"></li>
                    <li className="order44 absolute w-5 h-5"></li>
                    <li className="order55 absolute w-5 h-5"></li>
                  </ul>
                </div>

                <div>
                  <ul className="listorderr relative w-3/4 h-0.5 m-8 mt-8">
                    <li className="orderr1 absolute text-center">
                      <p className="recorder text-sm font-bold">
                        Order Received
                      </p>
                      <p className="smalltext text-xs">Order Received on</p>
                      <p className="smalltext text-xs">25 May 7AM</p>
                    </li>
                    <li className="orderr2 absolute text-center">
                      <p className="recorderr text-sm font-bold">
                        Order Confirmed
                      </p>
                      <p className="smalltextt text-xs">Order Confirmed on</p>
                      <p className="smalltextt text-xs">25 May 7AM</p>
                    </li>
                    <li className="orderr3 absolute text-center">
                      <p className="recorderr text-sm font-bold">
                        Order Shipped
                      </p>
                      <p className="smalltextt text-xs">Order Shipped on</p>
                      <p className="smalltextt text-xs">25 May 7AM</p>
                    </li>
                    <li className="orderr4 absolute text-center">
                      <p className="recorderr text-sm font-bold">
                        Out For Delivery
                      </p>
                      <p className="smalltextt text-xs">Order Shipped on</p>
                      <p className="smalltextt text-xs">25 May 7AM</p>
                    </li>
                    <li className="orderr5 absolute text-center">
                      <p className="recorderr text-sm font-bold">Delivered</p>
                      <p className="smalltextt text-xs">Expected Delivery On</p>
                      <p className="smalltextt text-xs">25 May 7AM</p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default Account;
