import Nav from "@/app/Components/NavBar/Nav";
import Products from "@/app/Components/Products/Products";
import "./MilkLink.css";

export default function Prod() {
  return (
    <div>
      <Nav />
      <Products />
      <img src="/78.jpg" className="carobanner w-full"></img>
      <div className="milklinkbanner">
        <div className="containerbox flex">
          <div className="categorieslist bg-white	">
            <ul className="flex flex-col  text-justify">
              <li className="pt-9 pl-8">Categories</li>

              <li className="top flex  items-center   pt-7 ml-8 w-3/4">
                <div className="firstmilk h-5"></div>
                <div className="firsttext pl-2.5 font-bold w-4/5">A2 Milk</div>
              </li>
              <li className="top flex  items-center   pt-7 ml-8 w-3/4">
                <div className="firstmilk h-5"></div>
                <div className="firsttext pl-2.5 font-bold w-4/5">
                  Standardized Milk
                </div>
              </li>

              <li className="top flex  items-center   pt-7 ml-8 w-3/4">
                <div className="firstmilk h-5"></div>
                <div className="firsttext pl-2.5 font-bold w-4/5">All</div>
              </li>
            </ul>
          </div>
          <div className="w-64 productt1 rounded-lg bg-white">
            <img className="milk pt-3 m-auto" src="/3.png" alt="Butter"></img>
            <div className="flex items-center">
              <img
                className="pl-2.5	pt-2.5 w-14 h-7"
                src="/21.png"
                alt="Reviews"
              ></img>
              <span className="review pl-2.5 pt-2.5 text-xs">2 Reviews</span>
            </div>
            <div className="milktext text-3xl font-bold pt-2.5 pl-2">
              A2 Milk
            </div>
            <div className="flex justify-between items-center">
              <div className="price m-2.5 flex justify-between items-center">
                <span className="inprice text-2xl font-bold">&#8377;40</span>
                <del className="delprice opacity-50">&#8377;60</del>
              </div>
              <div className="ml m-2.5 flex justify-center items-center">
                <span className="mlprice pt-1">500ml</span>
                <span className="pl-1 flex">
                  <img src="/13.png"></img>
                </span>
              </div>
            </div>
            <div className="cart flex justify-between items-center">
              <div className=" button1 flex justify-around items-center m-2.5 py-2.5">
                <button className="subbutton justify-self-center">-</button>
                <div className="justify-self-center">5</div>
                <button className="addbutton justify-self-center">+</button>
              </div>
              <button className="button2 flex justify-center items-center m-1 rounded-lg">
                <img src="14.png" alt="cart" className=""></img>
              </button>
            </div>
          </div>

          <div className="w-64 productt1 rounded-lg bg-white">
            <img className="milk pt-3 m-auto" src="/40.png" alt="Butter"></img>
            <div className="flex items-center">
              <img
                className="pl-2.5	pt-2.5 w-14 h-7"
                src="/21.png"
                alt="Reviews"
              ></img>
              <span className="review pl-2.5 pt-2.5 text-xs">2 Reviews</span>
            </div>
            <div className="milkytext  font-bold pt-2.5 pl-2 text-2xl">
              Standardized Milk
            </div>
            <div className="flex justify-between items-center">
              <div className="price m-2.5 flex justify-between items-center">
                <span className="inprice text-2xl font-bold">&#8377;40</span>
                <del className="delprice opacity-50">&#8377;60</del>
              </div>
              <div className="ml m-2.5 flex justify-center items-center">
                <span className="mlprice pt-1">500ml</span>
                <span className="pl-1 flex">
                  <img src="/13.png"></img>
                </span>
              </div>
            </div>
            <div className="cart flex justify-between items-center">
              <div className=" button1 flex justify-around items-center m-2.5 py-2.5">
                <button className="subbutton justify-self-center">-</button>
                <div className="justify-self-center">5</div>
                <button className="addbutton justify-self-center">+</button>
              </div>
              <button className="button2 flex justify-center items-center m-1 rounded-lg">
                <img src="14.png" alt="cart" className=""></img>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
