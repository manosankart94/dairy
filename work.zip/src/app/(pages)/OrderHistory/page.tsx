import Nav from "@/app/Components/NavBar/Nav";
import Calendar from "react-calendar";
import "./OrderPage.css";

export default function OrderPage() {
  return (
    <div>
      <Nav />
      <div className="milkimage bg-cover box-border text-3xl bg-no-repeat pt-12 pl-44">
        <p className="font-bold">Your Orders</p>
        <p className="text-base pl-1.5">Your Orders/Order History</p>
      </div>

      <div className="orderpage py-7">
        <div className="flexorder m-auto flex bg-white w-10/12">
          <div className="orderleft flex justify-center items-center  py-5 m-5">
            <img src="/72.png" alt="milk"></img>
          </div>
          <div className="orderright w-10/12">
            <div className="flex justify-between">
              <div>
                <p className="a2text text-2xl pt-4">
                  A2 Milk<span className="mltext px-2 text-lg">500ml</span>
                </p>
                <p className="packtext">2 packs</p>
              </div>
              <button className="vieworderbutton text-center mr-12 text-sm text-center rounded font-medium w-36 mt-5">
                View Order Details
              </button>
            </div>
            <div>
              <ul className="listorder relative w-3/4 h-0.5">
                <li className="order1 absolute w-5 h-5"></li>
                <li className="order2 absolute w-5 h-5"></li>
                <li className="order3 absolute w-5 h-5"></li>
                <li className="order4 absolute w-5 h-5"></li>
                <li className="order5 absolute w-5 h-5"></li>
              </ul>
            </div>

            <div>
              <ul className="listorderr relative w-3/4 mt-5">
                <li className="orderr1 absolute text-center">
                  <p className="recorder text-sm font-bold">Order Received</p>
                  <p className="smalltext text-xs">Order Received on</p>
                  <p className="smalltext text-xs">25 May 7AM</p>
                </li>
                <li className="orderr2 absolute text-center">
                  <p className="recorderr text-sm font-bold">Order Confirmed</p>
                  <p className="smalltextt text-xs">Order Confirmed on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr3 absolute text-center">
                  <p className="recorderr text-sm font-bold">Order Shipped</p>
                  <p className="smalltextt text-xs">Order Shipped on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr4 absolute text-center">
                  <p className="recorderr text-sm font-bold">
                    Out For Delivery
                  </p>
                  <p className="smalltextt text-xs">Order Shipped on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr5 absolute text-center">
                  <p className="recorderr text-sm font-bold">Delivered</p>
                  <p className="smalltextt text-xs">Expected Delivery On</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="flexorderr m-auto  mt-5 flex bg-white w-10/12">
          <div className="orderleft flex justify-center items-center  py-5 m-5">
            <img src="/72.png" alt="milk"></img>
          </div>
          <div className="orderright w-10/12">
            <div className="flex justify-between">
              <div className="">
                <p className="a2text text-2xl pt-4">
                  A2 Milk<span className="mltext px-2 text-lg">500ml</span>
                </p>
                <p className="packtext">2 packs</p>
              </div>
              <button className="vieworderbutton text-center mr-12 text-sm text-center rounded font-medium w-36 mt-5">
                View Order Details
              </button>
              
            </div>
            <div>
              <ul className="listorder relative w-3/4 h-0.5">
                <li className="order11 absolute w-5 h-5"></li>
                <li className="order21 absolute w-5 h-5"></li>
                <li className="order31 absolute w-5 h-5"></li>
                <li className="order41 absolute w-5 h-5"></li>
                <li className="order51 absolute w-5 h-5"></li>
              </ul>
            </div>

            <div>
              <ul className="listorderr relative w-3/4 mt-5">
                <li className="orderr1 absolute text-center">
                  <p className="recorder text-sm font-bold">Order Received</p>
                  <p className="smalltext text-xs">Order Received on</p>
                  <p className="smalltext text-xs">25 May 7AM</p>
                </li>
                <li className="orderr2 absolute text-center">
                  <p className="recorderr text-sm font-bold">Order Confirmed</p>
                  <p className="smalltextt text-xs">Order Confirmed on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>

                <li className="ord absolute text-center">
                  <p className="rec text-sm font-bold">Order Cancelled</p>
                  <p className="smalltextt text-xs">Order Cancelled on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>

                <li className="orderr3 absolute text-center">
                  <p className="recorderr text-sm font-bold">Order Shipped</p>
                  <p className="smalltextt text-xs">Order Shipped on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr4 absolute text-center">
                  <p className="recorderr text-sm font-bold">
                    Out For Delivery
                  </p>
                  <p className="smalltextt text-xs">Order Shipped on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr5 absolute text-center">
                  <p className="recorderr text-sm font-bold">Delivered</p>
                  <p className="smalltextt text-xs">Expected Delivery On</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="flexorder m-auto  mt-5 flex bg-white w-10/12">
          <div className="orderleft flex justify-center items-center  py-5 m-5">
            <img src="/72.png" alt="milk"></img>
          </div>
          <div className="orderright w-10/12">
            <div className="flex justify-between">
              <div className="">
                <p className="a2text text-2xl pt-4">
                  A2 Milk<span className="mltext px-2 text-lg">500ml</span>
                </p>
                <p className="packtext">2 packs</p>
              </div>
              <button className="vieworderbutton text-center mr-12 text-sm text-center rounded font-medium w-36 mt-5">
                View Order Details
              </button>
            </div>
            <div>
              <ul className="listorder relative w-3/4 h-0.5">
                <li className="order1 absolute w-5 h-5"></li>
                <li className="order2 absolute w-5 h-5"></li>
                <li className="order3 absolute w-5 h-5"></li>
                <li className="order4 absolute w-5 h-5"></li>
                <li className="order5 absolute w-5 h-5"></li>
              </ul>
            </div>

            <div>
              <ul className="listorderr relative w-3/4 mt-5">
                <li className="orderr1 absolute text-center">
                  <p className="recorder text-sm font-bold">Order Received</p>
                  <p className="smalltext text-xs">Order Received on</p>
                  <p className="smalltext text-xs">25 May 7AM</p>
                </li>
                <li className="orderr2 absolute text-center">
                  <p className="recorderr text-sm font-bold">Order Confirmed</p>
                  <p className="smalltextt text-xs">Order Confirmed on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr3 absolute text-center">
                  <p className="recorderr text-sm font-bold">Order Shipped</p>
                  <p className="smalltextt text-xs">Order Shipped on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr4 absolute text-center">
                  <p className="recorderr text-sm font-bold">
                    Out For Delivery
                  </p>
                  <p className="smalltextt text-xs">Order Shipped on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr5 absolute text-center">
                  <p className="recorderr text-sm font-bold">Delivered</p>
                  <p className="smalltextt text-xs">Expected Delivery On</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="flexorderr m-auto  mt-5 flex bg-white w-10/12">
          <div className="orderleft flex justify-center items-center  py-5 m-5">
            <img src="/72.png" alt="milk"></img>
          </div>
          <div className="orderright w-10/12">
            <div className="flex justify-between">
              <div className="">
                <p className="a2text text-2xl pt-4">
                  A2 Milk<span className="mltext px-2 text-lg">500ml</span>
                </p>
                <p className="packtext">2 packs</p>
              </div>
              <button className="vieworderbutton text-center mr-12 text-sm text-center rounded font-medium w-36 mt-5">
                View Order Details
              </button>
            </div>
            <div>
              <ul className="listorder relative w-3/4 h-0.5">
                <li className="order11 absolute w-5 h-5"></li>
                <li className="order21 absolute w-5 h-5"></li>
                <li className="order31 absolute w-5 h-5"></li>
                <li className="order41 absolute w-5 h-5"></li>
                <li className="order51 absolute w-5 h-5"></li>
              </ul>
            </div>

            <div>
              <ul className="listorderr relative w-3/4 mt-5">
                <li className="orderr1 absolute text-center">
                  <p className="recorder text-sm font-bold">Order Received</p>
                  <p className="smalltext text-xs">Order Received on</p>
                  <p className="smalltext text-xs">25 May 7AM</p>
                </li>
                <li className="orderr2 absolute text-center">
                  <p className="recorderr text-sm font-bold">Order Confirmed</p>
                  <p className="smalltextt text-xs">Order Confirmed on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>

                <li className="ord absolute text-center">
                  <p className="rec text-sm font-bold">Order Cancelled</p>
                  <p className="smalltextt text-xs">Order Cancelled on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>


                <li className="orderr3 absolute text-center">
                  <p className="recorderr text-sm font-bold">Order Shipped</p>
                  <p className="smalltextt text-xs">Order Shipped on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr4 absolute text-center">
                  <p className="recorderr text-sm font-bold">
                    Out For Delivery
                  </p>
                  <p className="smalltextt text-xs">Order Shipped on</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
                <li className="orderr5 absolute text-center">
                  <p className="recorderr text-sm font-bold">Delivered</p>
                  <p className="smalltextt text-xs">Expected Delivery On</p>
                  <p className="smalltextt text-xs">25 May 7AM</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}



