import Link from 'next/link';
import "./Checkout.css";




export default function CheckOut() {
    return (
     <div className="flex justify-center">
        <div className="checkleft"></div>
        <div className="checkright"></div>
     </div>
    );
  }
